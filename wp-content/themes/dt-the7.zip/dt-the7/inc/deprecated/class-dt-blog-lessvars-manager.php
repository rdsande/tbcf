<?php
/**
 * Deprecated. The7 less vars manager modification for shortcode.
 *
 * @package The7
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class DT_Blog_LessVars_Manager
 */
class DT_Blog_LessVars_Manager extends The7_Less_Vars_Shortcode_Manager {
}