<?php
/**
 * Deprecated. The7 less vars factory.
 *
 * @package The7
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class Presscore_Lib_LessVars_Factory
 */
class Presscore_Lib_LessVars_Factory extends The7_Less_Vars_Factory {
}