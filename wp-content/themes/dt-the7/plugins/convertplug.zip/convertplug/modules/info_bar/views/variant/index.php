<?php
/**
 * Prohibit direct script loading.
 *
 * @package Convert_Plus.
 */

// We agreed.
